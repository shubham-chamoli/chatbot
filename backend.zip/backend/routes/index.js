var express = require('express');
const passport = require('passport');
var router = express.Router();
const userModel = require("./users.js");

const localStrategy = require("passport-local");
passport.use(new localStrategy(userModel.authenticate()));
/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});
router.get('/login', function(req, res, next) {
  res.render('login', { title: 'Express' });
});
router.get('/chat', function(req, res, next) {
res.render('chat')
});
router.get('/fail', function(req, res, next) {
  res.send('Wrong Input');
});

router.post('/register',function(req,res){
  var userdata = new userModel({
    username: req.body.username,
    secret: req.body.secret
  });

  userModel.register(userdata, req.body.password)
    .then(function (registereduser){
      passport.authenticate("local")(req, res, function(){
        res.redirect('/chat');
      })
    })
});


router.post("/login", passport.authenticate("local", {
   successRedirect: "/chat",
   failureRedirect: "/fail"
 }), function(req,res){ })

 function isLoggedIn(req, res, next) { 
  if (req.isAuthenticated()) {
     return next(); 
    } 
    res.redirect("/chat"); 
  }


module.exports = router;
